---
title: "My Trip"
date: 2025-01-13
draft: false
tags: ["climb"]
---

Some intro text about the trip goes here.

## Photos

{{< gallery id="gallery" >}}

And any other content after the gallery.

